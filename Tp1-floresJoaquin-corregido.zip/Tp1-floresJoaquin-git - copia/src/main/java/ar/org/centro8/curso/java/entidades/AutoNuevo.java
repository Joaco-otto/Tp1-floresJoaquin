package ar.org.centro8.curso.java.entidades;
/*
 * Esta clase AutoNuevo hereda de la clase Vehiculo.
 * utiliza una estructura condicional if-else 
 * para hacer una validacion de  radio 
 * que no sea nula o no este asignado a otro vehiculo
 */
 
  
public class AutoNuevo extends Vehiculo {
    private AutoNuevo(String marca, String modelo,String color ,Radio radio,Double precio) {
        super(marca, modelo,color,precio);
        this.conectarRadio(radio);
    }
    public static AutoNuevo crearAutoNuevo(String marca, String modelo, String color, Radio radio, Double precio) {
        if (radio == null) {
            System.out.println(" No se puede crear AutoNuevo con una radio nula.");
            return null;
        }

        if (radio.getVehiculo() != null) {
            System.out.println(" La radio ya está asignada a otro vehículo, usa una que no este asignada ");
            return null;
        }
           return new AutoNuevo(marca, modelo, color, radio, precio);
    }

        @Override
        public String tipo() {
         return "Auto Nuevo";
    }
}



