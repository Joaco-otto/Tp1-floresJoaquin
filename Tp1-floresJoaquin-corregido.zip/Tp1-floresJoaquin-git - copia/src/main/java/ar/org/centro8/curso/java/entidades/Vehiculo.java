package ar.org.centro8.curso.java.entidades;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;
@Getter

/*
 * Clase "abstracta" llamada vehiculo que nos servira de base para
 * crear otros tipos de vehiculos(AutoNuevo,AutoClasico y Colectivo).
 * No se puede crear un objeto de tipo Vehiculo directamente.
 */
public abstract class Vehiculo {

    private String marca;
    private String modelo;
    private String color;
    private Double precio;
    @Setter(AccessLevel.NONE)
    protected Radio radio;
    
    /**
     * 
     * Se define el constructor 
     * Se omite Radio por que se puede agregar,cambiar o quitar con metodos
     *
     * @param marca
     * @param modelo
     * @param color
     * @param precio
     */
    public Vehiculo(String marca, String modelo, String color,Double precio){
        this.marca= marca;
        this.modelo=modelo;
        this.precio=precio;
        this.color=color;
    }

    /**
     * Metodo abstracto, cada tipo de vehiculo tendra su propia version del metodo.
     * @return
     */
    public abstract String tipo();

    //  ** Metodos con Radio **

/**
 * Este metodo realiza varias validaciones antes de conectar una radio  
 * 
 * @param nuevaRadio 
 */
    public void conectarRadio(Radio nuevaRadio) {
        if (nuevaRadio == null) {
            System.out.println("No se puede asignar una radio nula.");
            return;
        }
    
        // Si la nueva radio ya está en otro vehículo distinto a este
        if (nuevaRadio.getVehiculo() != null && nuevaRadio.getVehiculo() != this) {
            Vehiculo otroVehiculo = nuevaRadio.getVehiculo();
            otroVehiculo.quitarRadio();
            System.out.println("La radio fue retirada del vehículo anterior.");
        }
    
        // Si este vehículo ya tiene una radio, desvincularla
        if (this.radio != null) {
            this.radio.setVehiculo(null);
            System.out.println("Radio anterior quitada del vehículo actual.");
        }
    
        // Asignar la nueva radio
        this.radio = nuevaRadio;
        nuevaRadio.setVehiculo(this);
        System.out.println("Radio asignada correctamente al vehículo actual.");
    }



    /**
     * 
     */
    public void quitarRadio() {
    if (this.radio != null) {
        this.radio.setVehiculo(null);
        this.radio = null;
        System.out.println("Radio quitada del vehículo.");
    } else {
        System.out.println("Este vehículo no tiene una radio para quitar.");
    }
}

        /**
         * Se sobreescribe toString() para que las clases hijas
         * hereden el comportamiento sin necesidad de escribirlo
         */
           @Override
           public String toString() {
           return " -TipoVehiculo:   " + tipo() +
                "   - Marca:  " + marca  +
                ",  - Modelo: " + modelo +
                ",  - Color:  " + color  +
                ",  - Precio: " + precio + " USD " +
                ",  - Radio:  " + (radio != null ? radio.getMarca() + " (" + radio.getPotencia() + "W)" : "Sin radio");
       
    }
}

    

