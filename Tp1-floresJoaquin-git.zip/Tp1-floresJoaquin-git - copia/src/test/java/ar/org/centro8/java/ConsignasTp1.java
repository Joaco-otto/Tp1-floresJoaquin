package ar.org.centro8.java;

public class ConsignasTp1 {

}
