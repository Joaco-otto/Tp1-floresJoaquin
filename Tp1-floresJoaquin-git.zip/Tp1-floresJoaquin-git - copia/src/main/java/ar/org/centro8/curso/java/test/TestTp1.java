package ar.org.centro8.curso.java.test;

import ar.org.centro8.curso.java.entidades.AutoClasico;
import ar.org.centro8.curso.java.entidades.AutoNuevo;
import ar.org.centro8.curso.java.entidades.Colectivo;
import ar.org.centro8.curso.java.entidades.Radio;


public class TestTp1 {
    public static void main(String[] args) {

                 System.out.println(" TEST RADIO ");
        
        Radio radio1 = new Radio("Sony", 100);
        Radio radio2 = new Radio("Pioneer", 80);
        Radio radio3 = new Radio("JVC", 95); 
        Radio radio4 = new Radio("JBL", 120);
        Radio radio5 = new Radio("Alpine", 110);
        Radio radio6 = new Radio("Xiaomi",123);
        System.out.println(radio1);
        System.out.println(radio2);
        System.out.println(radio3);
        System.out.println(radio4);
        System.out.println(radio5);
        System.out.println(radio6);

                   System.out.println(" TEST AUTO CLASICO ");
        AutoClasico autocClasico1 = new AutoClasico("Dodge", "Charger", "negro",20200.0 );
        AutoClasico autoClasico2 = new AutoClasico("Nissan", "Skyline GT-R","Gris", 15600.0);
        AutoClasico autoClasico3 = new AutoClasico("DMC", "DeLorean", "Gris", 18900.0);
      
        System.out.println(autocClasico1);
        System.out.println(autoClasico2);
        System.out.println(autoClasico3);
        
                  System.out.println(" TEST AUTO NUEVO ");

        AutoNuevo auto3 = AutoNuevo.crearAutoNuevo("Toyota", "Corolla", "Bordo", radio6, 30000.0);
        AutoNuevo auto4 = AutoNuevo.crearAutoNuevo("Renault", "Kardian", "Azul", radio5, 25000.0);
        System.out.println(auto3);
        System.out.println(auto4);

                    System.out.println("TEST DE COLECTIVO ");
        Colectivo colectivo1 = new Colectivo("Mercedes", "Benz","Amarillo", 130000.0);
        Colectivo colectivo2 = new Colectivo("Plymouth", "Reliant", "Amarillo", 120000.0);
        System.out.println(colectivo1);
        System.out.println(colectivo2);
        
        System.out.println("** PRUEBAS CON CONECTAR.RADIO ** ");

          autocClasico1.conectarRadio(radio3);
          System.out.println(" La radio del "+ autocClasico1.getMarca() + autocClasico1.getModelo() + " es un " + autocClasico1.getRadio().getMarca());
          System.out.println(" El vehiculo de la radio es " + radio3.getVehiculo().getMarca() + autocClasico1.getModelo() + " que es un " + autocClasico1.tipo());
          autocClasico1.conectarRadio(radio4);// No deberia agregar por que "autoClasico1" ya tiene una asignada 
          System.out.println("la radio del " + autocClasico1.getRadio().getMarca());

        System.out.println("** PRUEBAS CON CAMBIAR.RADIO ** ");
        
          autocClasico1.conectarRadio(radio2);// radio2 ya esta en otro vehiculo, por lo tanto "autoClasico1" no cambia de radio
          System.out.println("La radio del " + autocClasico1.getMarca() + autocClasico1.getModelo() + "es un " + autocClasico1.getRadio().getMarca());
        
          // usamos una radio que no este asignada
          autocClasico1.conectarRadio(radio4);
          System.out.println("La radio del " + autocClasico1.getMarca() + autocClasico1.getModelo() + "es un " + autocClasico1.getRadio().getMarca());


          colectivo1.conectarRadio(radio4);
          System.out.println(" La radio de " + colectivo1.getMarca() + " es un " + radio4.getMarca());
          System.out.println(colectivo1);
          System.out.println(radio1.getVehiculo());
          System.out.println(radio2.getVehiculo());
          System.out.println(radio3.getVehiculo());
          System.out.println(radio4.getVehiculo());
          System.out.println(radio5.getVehiculo());// Esta radio esta disponible
          System.out.println(radio6.getVehiculo());// esta disponible

          autoClasico2.conectarRadio(radio6);
          System.out.println(autoClasico2);
          System.out.println(radio6.getVehiculo());
          System.out.println(radio4.getVehiculo());
          colectivo1.conectarRadio(radio6);
          System.out.println(colectivo1);
          autoClasico2.conectarRadio(radio4);
          System.out.println(autoClasico2);
          autoClasico3.conectarRadio(radio4);
          System.out.println(autoClasico3);
          autoClasico3.conectarRadio(radio3);
          System.out.println(autoClasico3);
        System.out.println(radio1.getVehiculo());
        
  AutoNuevo auto1 =AutoNuevo.crearAutoNuevo("ford", "fiesta", "azul", radio3, 15002.0);
  System.out.println(auto1);
  AutoNuevo auto2 =AutoNuevo.crearAutoNuevo("ford", "fiesta", "azul", null, 15002.0);
  System.out.println(auto2);
  autoClasico2.conectarRadio(null);
  System.out.println(autoClasico2);
  autoClasico2.conectarRadio(null);
  
    }

    }


