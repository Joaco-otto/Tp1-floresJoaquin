package ar.org.centro8.curso.java.entidades;
/*
 * Esta clase AutoNuevo hereda los atributos de la clase Vehiculo.
 * tiene un constructor privado y utiliza un metodo estatico para 
 * tener el control de la creacion de objetos de la clase AutoNuevo
 * haciendo validaciones previamente.
 */
 
  
public class AutoNuevo extends Vehiculo {
    private AutoNuevo(String marca, String modelo,String color ,Radio radio,Double precio) {
        super(marca, modelo,color,precio);
        this.conectarRadio(radio);
    }
    public static AutoNuevo crearAutoNuevo(String marca, String modelo, String color, Radio radio, Double precio) {
        if (radio == null) {
            System.out.println(" No se puede crear AutoNuevo con una radio nula.");
            return null;
        }

        if (radio.getVehiculo() != null) {
            System.out.println(" La radio ya está asignada a otro vehículo, usa una que no este asignada ");
            return null;
        }
           return new AutoNuevo(marca, modelo, color, radio, precio);
    }

        @Override
        public String tipo() {
         return "Auto Nuevo";
    }
}



